# Rafid Enterprise NoCrash V4

Stable simple native Android app.
