package com.rafid.enterprise;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String DATA_KEY = "rafid_simple_history_v4";
    private static final int REQ_BACKUP = 401;
    private static final int REQ_RESTORE = 402;

    private SharedPreferences prefs;
    private JSONArray entries = new JSONArray();

    private LinearLayout main;
    private ScrollView scroll;
    private EditText nameEt, subjectEt, amountEt, dateEt;
    private TextView totalTv, countTv;
    private Button saveBtn;
    private String editId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("rafid_store_v4", MODE_PRIVATE);
        load();
        build();
        render();
    }

    private void load() {
        try {
            entries = new JSONArray(prefs.getString(DATA_KEY, "[]"));
        } catch (Exception e) {
            entries = new JSONArray();
        }
    }

    private void saveStore() {
        prefs.edit().putString(DATA_KEY, entries.toString()).apply();
    }

    private void build() {
        scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(2, 6, 23));
        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(14), dp(14), dp(14), dp(20));
        scroll.addView(main);
        setContentView(scroll);
    }

    private void render() {
        main.removeAllViews();
        header();
        form();
        history();
        backupPanel();
    }

    private void header() {
        LinearLayout card = card(Color.rgb(15, 23, 42));
        card.setBackground(gradientRound(Color.rgb(15,23,42), Color.rgb(30,64,175), dp(24)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row);

        TextView logo = new TextView(this);
        logo.setText("RE");
        logo.setGravity(Gravity.CENTER);
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(20);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable lg = new GradientDrawable();
        lg.setShape(GradientDrawable.OVAL);
        lg.setColor(Color.rgb(34,197,94));
        lg.setStroke(dp(3), Color.WHITE);
        logo.setBackground(lg);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(62), dp(62));
        logoLp.setMargins(0,0,dp(12),0);
        row.addView(logo, logoLp);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        TextView title = tv("মেসার্স রাফিদ এন্টারপ্রাইজ", 19, Color.rgb(250,204,21), true);
        title.setSingleLine(true);
        texts.addView(title);

        TextView sub = tv("নাম, বিষয়, টাকা, তারিখ ও সময় হিসাব", 13, Color.rgb(219,234,254), true);
        texts.addView(sub);

        LinearLayout sums = new LinearLayout(this);
        sums.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(14), 0, 0);
        card.addView(sums, sp);

        totalTv = summaryBox(sums, "মোট টাকা", "৳0");
        countTv = summaryBox(sums, "মোট হিসাব", "0");

        updateSummary();
        main.addView(card);
    }

    private TextView summaryBox(LinearLayout parent, String label, String value) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        b.setBackground(round(Color.rgb(2, 6, 23), dp(16), Color.rgb(51,65,85)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(4), 0, dp(4), 0);
        parent.addView(b, lp);

        TextView l = tv(label, 12, Color.rgb(203,213,225), true);
        l.setGravity(Gravity.CENTER);
        b.addView(l);

        TextView v = tv(value, 17, Color.rgb(134,239,172), true);
        v.setGravity(Gravity.CENTER);
        b.addView(v);
        return v;
    }

    private void form() {
        LinearLayout c = card(Color.rgb(10, 18, 36));
        c.addView(section("নতুন হিসাব লিখুন"));

        nameEt = edit("নাম লিখুন", false);
        c.addView(labelWrap("নাম", nameEt, 56));

        subjectEt = edit("বিষয় লিখুন", false);
        subjectEt.setSingleLine(false);
        subjectEt.setMinLines(3);
        c.addView(labelWrap("বিষয়", subjectEt, 100));

        amountEt = edit("কত টাকা", true);
        c.addView(labelWrap("কত টাকা", amountEt, 56));

        dateEt = edit("", false);
        dateEt.setText(now());
        c.addView(labelWrap("তারিখ ও সময়", dateEt, 56));

        saveBtn = new Button(this);
        saveBtn.setAllCaps(false);
        saveBtn.setText("💾 হিসাব সেভ করুন");
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setTextSize(16);
        saveBtn.setTypeface(Typeface.DEFAULT_BOLD);
        saveBtn.setBackground(gradientRound(Color.rgb(56,189,248), Color.rgb(34,197,94), dp(16)));
        saveBtn.setOnClickListener(v -> saveEntry());
        c.addView(saveBtn, new LinearLayout.LayoutParams(-1, dp(56)));

        main.addView(c);
    }

    private void history() {
        LinearLayout c = card(Color.rgb(10, 18, 36));
        c.addView(section("সেভ হিস্ট্রি"));

        if (entries.length() == 0) {
            TextView empty = tv("এখনো কোনো হিসাব লেখা হয়নি।", 16, Color.rgb(148,163,184), true);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(18), 0, dp(18));
            c.addView(empty);
        } else {
            for (int i = entries.length() - 1; i >= 0; i--) {
                try {
                    c.addView(historyCard(entries.getJSONObject(i)));
                } catch (Exception ignored) {}
            }
        }

        main.addView(c);
    }

    private View historyCard(JSONObject o) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(round(Color.rgb(7, 13, 28), dp(18), Color.rgb(56,189,248)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);

        TextView name = tv("👤 " + o.optString("name"), 20, Color.WHITE, true);
        box.addView(name);

        TextView amount = tv("💰 " + money(o.optDouble("amount")), 21, Color.rgb(134,239,172), true);
        amount.setPadding(0, dp(6), 0, 0);
        box.addView(amount);

        TextView subject = tv("📝 বিষয়: " + o.optString("subject"), 17, Color.rgb(226,232,240), false);
        subject.setPadding(0, dp(10), 0, 0);
        subject.setSingleLine(false);
        box.addView(subject);

        TextView date = tv("🕒 তারিখ ও সময়: " + o.optString("dateTime"), 16, Color.rgb(203,213,225), true);
        date.setPadding(0, dp(8), 0, dp(12));
        date.setSingleLine(false);
        box.addView(date);

        Button edit = new Button(this);
        edit.setAllCaps(false);
        edit.setText("✏️ Edit");
        edit.setTextSize(15);
        edit.setTypeface(Typeface.DEFAULT_BOLD);
        edit.setTextColor(Color.WHITE);
        edit.setBackground(round(Color.rgb(31,41,59), dp(14), Color.rgb(71,85,105)));
        edit.setOnClickListener(v -> editEntry(o.optString("id")));
        box.addView(edit, new LinearLayout.LayoutParams(-1, dp(50)));

        return box;
    }

    private void backupPanel() {
        LinearLayout c = card(Color.rgb(10, 18, 36));
        c.addView(section("Backup & Restore"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button b1 = smallBtn("⬇️ Backup Save");
        b1.setOnClickListener(v -> backup());

        Button b2 = smallBtn("⬆️ Import / Restore");
        b2.setOnClickListener(v -> restore());

        row.addView(b1, new LinearLayout.LayoutParams(0, dp(54), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1);
        lp.setMargins(dp(8), 0, 0, 0);
        row.addView(b2, lp);

        c.addView(row);
        main.addView(c);
    }

    private void saveEntry() {
        String name = nameEt.getText().toString().trim();
        String sub = subjectEt.getText().toString().trim();
        double amount = parse(amountEt.getText().toString());
        String date = dateEt.getText().toString().trim();

        if (name.isEmpty()) { toast("নাম লিখুন"); return; }
        if (sub.isEmpty()) { toast("বিষয় লিখুন"); return; }
        if (amount <= 0) { toast("সঠিক টাকা লিখুন"); return; }
        if (date.isEmpty()) { toast("তারিখ ও সময় লিখুন"); return; }

        try {
            JSONObject o = new JSONObject();
            o.put("id", editId.isEmpty() ? String.valueOf(System.currentTimeMillis()) : editId);
            o.put("name", name);
            o.put("subject", sub);
            o.put("amount", amount);
            o.put("dateTime", date);

            if (editId.isEmpty()) {
                entries.put(o);
            } else {
                for (int i = 0; i < entries.length(); i++) {
                    if (editId.equals(entries.getJSONObject(i).optString("id"))) {
                        entries.put(i, o);
                        break;
                    }
                }
            }

            editId = "";
            saveStore();
            clearForm();
            render();
            toast("সেভ হয়েছে ✅");
        } catch (Exception e) {
            toast("Save error");
        }
    }

    private void editEntry(String id) {
        try {
            for (int i = 0; i < entries.length(); i++) {
                JSONObject o = entries.getJSONObject(i);
                if (id.equals(o.optString("id"))) {
                    nameEt.setText(o.optString("name"));
                    subjectEt.setText(o.optString("subject"));
                    amountEt.setText(String.valueOf(o.optDouble("amount")));
                    dateEt.setText(o.optString("dateTime"));
                    editId = id;
                    saveBtn.setText("✅ হিসাব আপডেট করুন");
                    scroll.smoothScrollTo(0, 0);
                    return;
                }
            }
        } catch (Exception ignored) {}
    }

    private void clearForm() {
        nameEt.setText("");
        subjectEt.setText("");
        amountEt.setText("");
        dateEt.setText(now());
        if (saveBtn != null) saveBtn.setText("💾 হিসাব সেভ করুন");
    }

    private void backup() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "rafid-backup-" + today() + ".json");
        startActivityForResult(i, REQ_BACKUP);
    }

    private void restore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        startActivityForResult(i, REQ_RESTORE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;

        try {
            Uri uri = data.getData();

            if (req == REQ_BACKUP) {
                JSONObject backup = new JSONObject();
                backup.put("app", "মেসার্স রাফিদ এন্টারপ্রাইজ");
                backup.put("version", "nocrash-v4");
                backup.put("entries", entries);

                OutputStream out = getContentResolver().openOutputStream(uri);
                out.write(backup.toString(2).getBytes("UTF-8"));
                out.close();
                toast("Backup save হয়েছে ✅");
            }

            if (req == REQ_RESTORE) {
                String txt = readAll(getContentResolver().openInputStream(uri));
                JSONObject obj = new JSONObject(txt);
                if (!obj.has("entries")) {
                    toast("ভুল backup file");
                    return;
                }
                entries = obj.getJSONArray("entries");
                saveStore();
                render();
                toast("Restore হয়েছে ✅");
            }
        } catch (Exception e) {
            toast("File error");
        }
    }

    private String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    private void updateSummary() {
        double total = 0;
        for (int i = 0; i < entries.length(); i++) {
            try { total += entries.getJSONObject(i).optDouble("amount"); } catch(Exception ignored) {}
        }
        if (totalTv != null) totalTv.setText(money(total));
        if (countTv != null) countTv.setText(String.valueOf(entries.length()));
    }

    private LinearLayout card(int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(15), dp(15), dp(15));
        c.setBackground(round(color, dp(22), Color.rgb(51,65,85)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(14));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView section(String s) {
        TextView t = tv(s, 22, Color.WHITE, true);
        t.setPadding(0, 0, 0, dp(14));
        return t;
    }

    private View labelWrap(String label, View v, int h) {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);

        TextView l = tv(label, 15, Color.rgb(226,232,240), true);
        l.setPadding(0, 0, 0, dp(7));
        w.addView(l);

        w.addView(v, new LinearLayout.LayoutParams(-1, dp(h)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        w.setLayoutParams(lp);
        return w;
    }

    private EditText edit(String hint, boolean number) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(100,116,139));
        e.setTextColor(Color.WHITE);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackground(round(Color.rgb(3,8,22), dp(16), Color.rgb(71,85,105)));
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private TextView tv(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button smallBtn(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(round(Color.rgb(31,41,59), dp(15), Color.rgb(71,85,105)));
        return b;
    }

    private GradientDrawable round(int color, int radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private GradientDrawable gradientRound(int c1, int c2, int radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(radius);
        return g;
    }

    private String now() { return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()); }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private String money(double n) { return "৳" + String.format(Locale.US, "%,.0f", n); }
    private double parse(String s) { try { return Double.parseDouble(s); } catch(Exception e) { return 0; } }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
